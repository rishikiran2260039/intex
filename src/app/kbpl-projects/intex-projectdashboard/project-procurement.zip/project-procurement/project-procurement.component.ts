import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-procurement',
  templateUrl: './project-procurement.component.html',
  styleUrls: ['./project-procurement.component.scss']
})
export class ProjectProcurementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
