import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-add-consignments',
  templateUrl: './add-consignments.component.html',
  styleUrls: ['./add-consignments.component.scss']
})
export class AddConsignmentsComponent implements OnInit {
  constructor() { }

  ngOnInit() {
  }
  

}
