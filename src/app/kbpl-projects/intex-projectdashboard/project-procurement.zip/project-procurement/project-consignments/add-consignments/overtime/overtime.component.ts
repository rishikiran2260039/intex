import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-overtime',
  templateUrl: './overtime.component.html',
  styleUrls: ['./overtime.component.scss']
})
export class OvertimeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
