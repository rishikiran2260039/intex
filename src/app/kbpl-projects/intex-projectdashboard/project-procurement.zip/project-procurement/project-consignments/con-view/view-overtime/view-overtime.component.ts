import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-overtime',
  templateUrl: './view-overtime.component.html',
  styleUrls: ['./view-overtime.component.scss']
})
export class ViewOvertimeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
