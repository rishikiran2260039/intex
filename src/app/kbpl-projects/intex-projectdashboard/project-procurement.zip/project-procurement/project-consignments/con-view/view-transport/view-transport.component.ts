import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-transport',
  templateUrl: './view-transport.component.html',
  styleUrls: ['./view-transport.component.scss']
})
export class ViewTransportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
