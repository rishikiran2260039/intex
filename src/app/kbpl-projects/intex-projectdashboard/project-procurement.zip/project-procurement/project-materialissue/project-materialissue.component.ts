import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-materialissue',
  templateUrl: './project-materialissue.component.html',
  styleUrls: ['./project-materialissue.component.scss']
})
export class ProjectMaterialissueComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
