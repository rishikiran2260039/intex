import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-po',
  templateUrl: './project-po.component.html',
  styleUrls: ['./project-po.component.scss']
})
export class ProjectPoComponent implements OnInit {
  filterToggle: boolean;
  constructor() { }

  ngOnInit() {
  }

}
