import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reconcilationgrid',
  templateUrl: './reconcilationgrid.component.html',
  styleUrls: ['./reconcilationgrid.component.scss']
})
export class ReconcilationgridComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
