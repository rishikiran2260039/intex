import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stocstockreconciliation-item',
  templateUrl: './stocstockreconciliation-item.component.html',
  styleUrls: ['./stocstockreconciliation-item.component.scss']
})
export class StocstockreconciliationItemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
