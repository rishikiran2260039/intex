import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-inventorycontrol',
  templateUrl: './project-inventorycontrol.component.html',
  styleUrls: ['./project-inventorycontrol.component.scss']
})
export class ProjectInventorycontrolComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
