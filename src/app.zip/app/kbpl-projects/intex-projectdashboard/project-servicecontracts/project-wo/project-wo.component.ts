import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-wo',
  templateUrl: './project-wo.component.html',
  styleUrls: ['./project-wo.component.scss']
})
export class ProjectWoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
