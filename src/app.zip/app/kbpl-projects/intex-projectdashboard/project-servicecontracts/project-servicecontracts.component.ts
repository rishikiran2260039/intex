import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-servicecontracts',
  templateUrl: './project-servicecontracts.component.html',
  styleUrls: ['./project-servicecontracts.component.scss']
})
export class ProjectServicecontractsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
