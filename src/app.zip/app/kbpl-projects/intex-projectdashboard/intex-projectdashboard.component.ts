import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-intex-projectdashboard',
  templateUrl: './intex-projectdashboard.component.html',
  styleUrls: ['./intex-projectdashboard.component.scss']
})
export class IntexProjectdashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
