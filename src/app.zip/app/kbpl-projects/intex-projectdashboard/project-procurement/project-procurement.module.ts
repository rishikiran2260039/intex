import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { ConfirmationPopoverModule } from 'angular-confirmation-popover';
import { ChartModule } from 'angular-highcharts';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { SharedModule } from 'src/app/shared/shared.module';
import { ProjectIndentsComponent } from './project-indents/project-indents.component';
import { ProjectPoComponent } from './project-po/project-po.component';
import { ProjectConsignmentsComponent } from './project-consignments/project-consignments.component';
import { ProjectGrnComponent } from './project-grn/project-grn.component';
import { ProjectMaterialissueComponent } from './project-materialissue/project-materialissue.component';
import { PoPendingComponent } from './project-po/po-pending/po-pending.component';
import { PoPublishedComponent } from './project-po/po-published/po-published.component';
import { PoArchivedComponent } from './project-po/po-archived/po-archived.component';
import { ActiveComponent } from './project-consignments/active/active.component';
import { ArchivedComponent } from './project-consignments/archived/archived.component';
import { MaterialActiveComponent } from './project-materialissue/material-active/material-active.component';
import { MaterialArchivesComponent } from './project-materialissue/material-archives/material-archives.component';
import { AddRequisitionDialogComponent } from 'src/app/purchase/requisition/add-requisition-dialog/add-requisition-dialog.component';
import { AddIndentsComponent } from './project-indents/add-indents/add-indents.component';

export const routes = [
  { path: '', redirectTo: 'indents', pathMatch: 'full' },
  { path: 'indents', component: ProjectIndentsComponent, data: { breadcrumb: '' } },
  { path: 'po', component: ProjectPoComponent,loadChildren: './project-po/project-po.module#ProjectPurchaseOrdersModule', data: { breadcrumb: '' } },
  { path: 'consignments', component: ProjectConsignmentsComponent,loadChildren: './project-consignments/project-consignments.module#ProjectConsignmentModule', data: { breadcrumb: '' } },
  { path: 'grn', component: ProjectGrnComponent, data: { breadcrumb: '' } },
  { path: 'materialissues', component: ProjectMaterialissueComponent,loadChildren: './project-materialissue/project-materialissue.module#ProjectMaterialIssueModule', data: { breadcrumb: '' } },
]
@NgModule({
  declarations: [ProjectIndentsComponent, ProjectPoComponent, ProjectConsignmentsComponent, ProjectGrnComponent, ProjectMaterialissueComponent, AddIndentsComponent],
  imports: [
    ChartModule,
    CommonModule, NgxChartsModule, RouterModule.forChild(routes),
    SharedModule, ConfirmationPopoverModule, ReactiveFormsModule, FormsModule,
    OwlDateTimeModule, OwlNativeDateTimeModule
  ],
  entryComponents:[AddIndentsComponent]
})
export class ProjectProcurementModule { }
