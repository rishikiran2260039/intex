import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-consignitemmodal',
  templateUrl: './consignitemmodal.component.html',
  styleUrls: ['./consignitemmodal.component.scss']
})
export class ConsignitemmodalComponent implements OnInit {

  constructor(public dialog:MatDialogRef<ConsignitemmodalComponent>) { }

  ngOnInit() {
  }
  
  items = [
    { ItemName : "Volvo", ItemCode: "FMX480", RequisitionRef: "OM/REQ/SPA-FEB-19/1057	",RequiredQty:"50",DeliveryDate:"21-07-2021",unitprice:"200" },
    { ItemName : "Caterpillar", ItemCode: " D85ESS 17",RequisitionRef: "OM/REQ/SPA/APR-20/1005",RequiredQty:"80",DeliveryDate:"24-08-2021",unitprice:"300" },
    { ItemName : "Mercedes", ItemCode: "All Models",RequisitionRef: "OM/REQ/SPA-FEB-19/1041",RequiredQty:"20",DeliveryDate:"12-09-2021",unitprice:"400" },
    { ItemName : "Tata ", ItemCode: "ACTROS 4841K",RequisitionRef: "OM/REQ/SPA/FEB-21/1077",RequiredQty:"30",DeliveryDate:"16-10-2021",unitprice:"300"},
    { ItemName : "Volvo", ItemCode: "D85ESS 86",RequisitionRef: "OM/REQ/SPA/MAR-21/1086",RequiredQty:"50",DeliveryDate:"13-12-2021",unitprice:"200"},
  ]

  close(){
    this.dialog.close();
  }


}

               