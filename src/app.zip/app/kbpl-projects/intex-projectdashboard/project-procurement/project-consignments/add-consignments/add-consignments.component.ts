import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-add-consignments',
  templateUrl: './add-consignments.component.html',
  styleUrls: ['./add-consignments.component.scss']
})
export class AddConsignmentsComponent implements OnInit {
  constructor(public dialogRef: MatDialogRef<AddConsignmentsComponent>,@Inject(MAT_DIALOG_DATA) public data:any) { }

  ngOnInit() {
  }
  
  close(): void {
    this.dialogRef.close();
  }
}
