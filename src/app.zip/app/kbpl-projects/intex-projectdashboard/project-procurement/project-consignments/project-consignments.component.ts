import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-consignments',
  templateUrl: './project-consignments.component.html',
  styleUrls: ['./project-consignments.component.scss']
})
export class ProjectConsignmentsComponent implements OnInit {

  constructor() { }

  ngOnInit() { 
  }

}
