import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-action-screen',
  templateUrl: './action-screen.component.html',
  styleUrls: ['./action-screen.component.scss']
})
export class ActionScreenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
