import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-invoices',
  templateUrl: './project-invoices.component.html',
  styleUrls: ['./project-invoices.component.scss']
})
export class ProjectInvoicesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
