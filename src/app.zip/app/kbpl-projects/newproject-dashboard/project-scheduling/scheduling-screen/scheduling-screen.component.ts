import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scheduling-screen',
  templateUrl: './scheduling-screen.component.html',
  styleUrls: ['./scheduling-screen.component.scss']
})
export class SchedulingScreenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
