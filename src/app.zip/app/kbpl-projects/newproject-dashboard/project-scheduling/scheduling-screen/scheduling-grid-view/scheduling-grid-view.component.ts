import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scheduling-grid-view',
  templateUrl: './scheduling-grid-view.component.html',
  styleUrls: ['./scheduling-grid-view.component.scss']
})
export class SchedulingGridViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
